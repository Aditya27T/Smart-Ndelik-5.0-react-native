import { initializeApp } from "firebase/app";
// DIUBAH: Impor 'initializeAuth' dan 'getReactNativePersistence'
import { initializeAuth, getReactNativePersistence } from "firebase/auth/react-native";
import { getFirestore } from "firebase/firestore";
import AsyncStorage from '@react-native-async-storage/async-storage';

const firebaseConfig = {
    apiKey: "AIzaSyC08Dj9pxNMpijJ5UtvDzwDf35Jv95TPq4",
    authDomain: "bijikopi-ec58e.firebaseapp.com",
    projectId: "bijikopi-ec58e",
    storageBucket: "bijikopi-ec58e.firebasestorage.app",
    messagingSenderId: "962221383374",
    appId: "1:962221383374:web:7eec88e688d1d74c95fa9f",
    measurementId: "G-L4K6ZGVDKC"
  };

  const app = initializeApp(firebaseConfig);

  // DIUBAH: Inisialisasi Auth dengan persistence untuk React Native
  // Ini adalah cara yang benar untuk memastikan komponen auth terdaftar sebelum digunakan.
  // getAuth() akan secara otomatis menggunakan instance yang sudah diinisialisasi ini.
  const auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
  });
  
  // Ekspor layanan lain yang akan kita gunakan
  export const db = getFirestore(app);
  
  // Ekspor auth yang sudah diinisialisasi dengan benar
  export { auth };
  
