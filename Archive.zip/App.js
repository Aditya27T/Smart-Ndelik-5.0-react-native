import React, { useCallback } from 'react';
import { SafeAreaView, StyleSheet } from 'react-native';
import AppNavigator from './navigation/AppNavigator';
import * as ExpoSplashScreen from 'expo-splash-screen';

// Impor semua provider yang dibutuhkan
import { SettingsProvider } from './context/SettingsContext';
import { AuthProvider } from './context/AuthContext';

ExpoSplashScreen.preventAutoHideAsync();

const App = () => {
  const onLayoutRootView = useCallback(async () => {
      await ExpoSplashScreen.hideAsync();
  }, []);

  return (
    // Bungkus aplikasi dari level tertinggi
    <AuthProvider>
      <SettingsProvider>
        <SafeAreaView style={styles.container} onLayout={onLayoutRootView}>
          <AppNavigator />
        </SafeAreaView>
      </SettingsProvider>
    </AuthProvider>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});

export default App;
