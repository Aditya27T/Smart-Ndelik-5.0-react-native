import React, { useState, useRef } from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Image, 
  TouchableOpacity, 
  Dimensions,
  Modal
} from 'react-native';
import { dummyData } from '../api/dummyData';
import ArticleScreen from './ArticleScreen'; 
import { supabase } from '../api/supabaseClient';


const { width: screenWidth } = Dimensions.get('window');

const DashboardScreen = ({ user, onLogout }) => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [showLogoutModal, setShowLogoutModal] = useState(false);
  const [showGuideModal, setShowGuideModal] = useState(false);
  const [showTipsModal, setShowTipsModal] = useState(false);
  const scrollViewRef = useRef(null);

  const [selectedCoffee, setSelectedCoffee] = useState(null);

  React.useEffect(() => {
    const fetchUserProfile = async () => {
      const { data, error } = await supabase
        .from('profiles')
        .select('username')
        .eq('id', user?.id)
        .single();
      if (error) {
        console.error('Error fetching user profile:', error);
      } else {
        setUserProfile(prevProfile => ({
          ...prevProfile,
          username: data.username
        }));
      }
    };
    fetchUserProfile();
  }, [user?.id]);

  const [userProfile, setUserProfile] = useState({
    username: user?.username || 'User',
    profileImage: user?.profileImage || 'https://via.placeholder.com/150'
  });

  const handleScroll = (event) => {
    const slide = Math.ceil(event.nativeEvent.contentOffset.x / screenWidth);
    if (slide !== currentSlide) {
      setCurrentSlide(slide);
    }
  };
  const handleCoffeeTypePress = (coffee) => {
    setSelectedCoffee(coffee);
  };

  const handleLogout = () => {
    onLogout();
    setShowLogoutModal(false);
  };

  if (selectedCoffee) {
    return (
      <ArticleScreen 
        coffee={selectedCoffee} 
        onClose={() => setSelectedCoffee(null)}
      />
    );
  }

  return (
    <View style={styles.container}>
      {/* Header tidak berubah */}
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={styles.headerLeft}>
            <Text style={styles.greeting}>Hi, {userProfile.username}!</Text>
          </View>
          <TouchableOpacity 
            style={styles.profileButton}
            onPress={() => setShowLogoutModal(true)}
          >
            <Image 
              source={{ uri: user?.profileImage }} 
              style={styles.profileImage}
            />
          </TouchableOpacity>
        </View>
      </View>

      {/* Main Content */}
      <ScrollView style={styles.mainContent} showsVerticalScrollIndicator={false}>
        {/* Image Slider tidak berubah */}
        <View style={styles.sliderContainer}>
          <ScrollView
            ref={scrollViewRef}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onScroll={handleScroll}
            scrollEventThrottle={50}
          >
            {dummyData.sliderPhotos.map((item) => (
              <View key={item.id} style={styles.slide}>
                <Image source={{ uri: item.name }} style={styles.sliderImage} />
                <View style={styles.sliderOverlay}>
                  <Text style={styles.sliderText}>Coffee Processing Excellence</Text>
                </View>
              </View>
            ))}
          </ScrollView>
          <View style={styles.pagination}>
            {dummyData.sliderPhotos.map((_, index) => (
              <View
                key={index}
                style={[
                  styles.paginationDot,
                  index === currentSlide && styles.paginationDotActive
                ]}
              />
            ))}
          </View>
        </View>

        {/* Coffee Types */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Coffee Types</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.coffeeTypesContainer}
          >
            {/* Pastikan onPress memanggil handleCoffeeTypePress yang sudah diubah */}
            {dummyData.coffeeTypes.map((coffee) => (
              <TouchableOpacity
                key={coffee.id}
                style={styles.coffeeTypeCard}
                onPress={() => handleCoffeeTypePress(coffee)} // Fungsi ini sudah diupdate
              >
                <Image source={{ uri: coffee.image }} style={styles.coffeeTypeImage} />
                <Text style={styles.coffeeTypeName}>{coffee.name}</Text>
              </TouchableOpacity>
            ))}
          </ScrollView>
        </View>

        {/* Interactive Features tidak berubah */}
        <View style={styles.section}>
          <TouchableOpacity 
            style={styles.featureCard}
            onPress={() => setShowGuideModal(true)}
          >
            <View style={styles.featureIcon}><Text style={styles.featureIconText}>❓</Text></View>
            <View style={styles.featureContent}>
              <Text style={styles.featureTitle}>How to Use</Text>
              <Text style={styles.featureSubtitle}>Complete guide for using the app</Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </TouchableOpacity>
          <TouchableOpacity 
            style={styles.featureCard}
            onPress={() => setShowTipsModal(true)}
          >
            <View style={styles.featureIcon}><Text style={styles.featureIconText}>💡</Text></View>
            <View style={styles.featureContent}>
              <Text style={styles.featureTitle}>Coffee Tips</Text>
              <Text style={styles.featureSubtitle}>Expert tips for better coffee</Text>
            </View>
            <Text style={styles.chevron}>›</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Semua Modal (Logout, Guide, Tips) tidak berubah */}
      {/* ... (kode modal Anda ada di sini, tidak perlu diubah) */}
      <Modal
        visible={showLogoutModal}
        transparent
        animationType="fade"
        onRequestClose={() => setShowLogoutModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.logoutIcon}>🚪</Text>
            <Text style={styles.modalTitle}>Logout</Text>
            <Text style={styles.modalText}>Are you sure you want to logout?</Text>
            <View style={styles.modalButtons}>
              <TouchableOpacity 
                style={[styles.modalButton, styles.cancelButton]}
                onPress={() => setShowLogoutModal(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.modalButton, styles.confirmButton]}
                onPress={handleLogout}
              >
                <Text style={styles.confirmButtonText}>Logout</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showGuideModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowGuideModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.guideModalContent}>
            <View style={styles.guideHeader}>
              <Text style={styles.guideIcon}>❓</Text>
              <Text style={styles.guideTitle}>How to Use Smart Ndelik 5.0</Text>
            </View>
            <ScrollView style={styles.guideContent}>
              <Text style={styles.guideStep}>1. Dashboard: View coffee processing overview and navigate features</Text>
              <Text style={styles.guideStep}>2. Monitoring: Watch real-time coffee bean selection process</Text>
              <Text style={styles.guideStep}>3. Settings: Configure camera, themes, and app preferences</Text>
              <Text style={styles.guideStep}>4. Profile: Manage your account and personal information</Text>
              <Text style={styles.guideStep}>5. Coffee Types: Learn about different coffee varieties</Text>
            </ScrollView>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowGuideModal(false)}
            >
              <Text style={styles.closeButtonText}>Got it!</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      <Modal
        visible={showTipsModal}
        transparent
        animationType="slide"
        onRequestClose={() => setShowTipsModal(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.guideModalContent}>
            <View style={styles.guideHeader}>
              <Text style={styles.guideIcon}>💡</Text>
              <Text style={styles.guideTitle}>Coffee Tips</Text>
            </View>
            <ScrollView style={styles.guideContent}>
              <Text style={styles.guideStep}>• Choose beans that look uniform in size and color</Text>
              <Text style={styles.guideStep}>• Store coffee beans in a cool, dry place away from light</Text>
              <Text style={styles.guideStep}>• Grind beans just before brewing for best flavor</Text>
              <Text style={styles.guideStep}>• Use the right water temperature (195-205°F)</Text>
              <Text style={styles.guideStep}>• Maintain proper coffee-to-water ratio (1:15-1:17)</Text>
              <Text style={styles.guideStep}>• Clean your equipment regularly for consistent taste</Text>
            </ScrollView>
            <TouchableOpacity 
              style={styles.closeButton}
              onPress={() => setShowTipsModal(false)}
            >
              <Text style={styles.closeButtonText}>Thanks!</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

// StyleSheet tidak berubah, Anda bisa copy-paste dari file asli Anda
const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#F5E6D3' 
  },
  header: { 
    backgroundColor: '#5D2E0A', 
    paddingBottom: 16, 
    paddingTop: 40 
  },
  headerContent: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'center', 
    paddingHorizontal: 20, 
    paddingTop: 10 
  },
  headerLeft: { 
    flex: 1 
  },
  greeting: { 
    fontSize: 24, 
    fontWeight: 'bold', 
    color: '#FFFFFF' 
  },
  profileButton: { 
    borderRadius: 25, 
    overflow: 'hidden', 
    borderWidth: 3, 
    borderColor: '#FFFFFF' 
  },
  profileImage: { 
    width: 50, 
    height: 50, 
    borderRadius: 25 
  },
  mainContent: { 
    flex: 1 
  },
  sliderContainer: { 
    height: 200, 
    marginBottom: 20 
  },
  slide: { 
    width: screenWidth, 
    height: 200 
  },
  sliderImage: { 
    width: '100%', 
    height: '100%', 
    resizeMode: 'cover' 
  },
  sliderOverlay: { 
    position: 'absolute', 
    bottom: 0, 
    left: 0, 
    right: 0, 
    backgroundColor: 'rgba(0,0,0,0.4)', 
    padding: 20 
  },
  sliderText: { 
    color: '#FFFFFF', 
    fontSize: 18, 
    fontWeight: 'bold' 
  },
  pagination: { 
    flexDirection: 'row', 
    justifyContent: 'center', 
    alignItems: 'center', 
    position: 'absolute', 
    bottom: 10, 
    left: 0, 
    right: 0 
  },
  paginationDot: { 
    width: 8, 
    height: 8, 
    borderRadius: 4, 
    backgroundColor: 'rgba(255,255,255,0.5)', 
    marginHorizontal: 4 
  },
  paginationDotActive: { 
    backgroundColor: '#FFFFFF' 
  },
  section: { 
    marginBottom: 24 
  },
  sectionTitle: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: '#8B4513', 
    marginBottom: 16, 
    paddingHorizontal: 20 
  },
  coffeeTypesContainer: { 
    paddingHorizontal: 20 
  },
  coffeeTypeCard: { 
    alignItems: 'center', 
    marginRight: 16, 
    backgroundColor: '#FFFFFF', 
    borderRadius: 16, 
    padding: 12, 
    shadowColor: '#000', 
    shadowOffset: { 
      width: 0, 
      height: 2 
    }, 
    shadowOpacity: 0.1, 
    shadowRadius: 4, 
    elevation: 3 
  },
  coffeeTypeImage: { 
    width: 80, 
    height: 80, 
    borderRadius: 40, 
    marginBottom: 8 
  },
  coffeeTypeName: { 
    fontSize: 14, 
    fontWeight: '600', 
    color: '#8B4513' 
  },
  featureCard: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    backgroundColor: '#FFFFFF', 
    marginHorizontal: 20, 
    marginBottom: 12, 
    padding: 16, 
    borderRadius: 16, 
    shadowColor: '#000', 
    shadowOffset: { 
      width: 0, 
      height: 2 
    }, 
    shadowOpacity: 0.1, 
    shadowRadius: 4, 
    elevation: 3 
  },
  featureIcon: { 
    width: 48, 
    height: 48, 
    borderRadius: 24, 
    backgroundColor: '#F5E6D3', 
    justifyContent: 'center', 
    alignItems: 'center', 
    marginRight: 16 
  },
  featureIconText: { 
    fontSize: 24 
  },
  featureContent: { 
    flex: 1 
  },
  featureTitle: { 
    fontSize: 16, 
    fontWeight: 'bold', 
    color: '#333', 
    marginBottom: 4 
  },
  featureSubtitle: { 
    fontSize: 14, 
    color: '#666' 
  },
  chevron: { 
    fontSize: 20, 
    color: '#A0A0A0' 
  },
  modalOverlay: { 
    flex: 1, 
    backgroundColor: 'rgba(0,0,0,0.5)', 
    justifyContent: 'center', 
    alignItems: 'center' 
  },
  modalContent: { 
    backgroundColor: '#FFFFFF', 
    borderRadius: 20, 
    padding: 24, 
    alignItems: 'center', 
    marginHorizontal: 40, 
    shadowColor: '#000', 
    shadowOffset: { 
      width: 0, 
      height: 4 
    }, 
    shadowOpacity: 0.25, 
    shadowRadius: 8, 
    elevation: 8 
  },
  logoutIcon: { 
    fontSize: 48 
  },
  modalTitle: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: '#333', 
    marginTop: 16, 
    marginBottom: 8 
  },
  modalText: { 
    fontSize: 16, 
    color: '#666', 
    textAlign: 'center', 
    marginBottom: 24 
  },
  modalButtons: { 
    flexDirection: 'row', 
    gap: 12 
  },
  modalButton: { 
    paddingVertical: 12, 
    paddingHorizontal: 24, 
    borderRadius: 12, 
    minWidth: 80, 
    alignItems: 'center' 
  },
  cancelButton: { 
    backgroundColor: '#F0F0F0' 
  },
  confirmButton: { 
    backgroundColor: '#8B4513' 
  },
  cancelButtonText: { 
    color: '#666', 
    fontWeight: '600' 
  },
  confirmButtonText: { 
    color: '#FFFFFF', 
    fontWeight: '600' 
  },
  guideModalContent: { 
    backgroundColor: '#FFFFFF', 
    borderRadius: 20, 
    marginHorizontal: 20, 
    maxHeight: '80%', 
    shadowColor: '#000', 
    shadowOffset: { 
      width: 0, 
      height: 4 
    }, 
    shadowOpacity: 0.25, 
    shadowRadius: 8, 
    elevation: 8 
  },
  guideHeader: { 
    alignItems: 'center', 
    padding: 24, 
    paddingBottom: 16 
  },
  guideIcon: { 
    fontSize: 32 
  },
  guideTitle: { 
    fontSize: 20, 
    fontWeight: 'bold', 
    color: '#333', 
    marginTop: 12 
  },
  guideContent: { 
    paddingHorizontal: 24, 
    maxHeight: 300 
  },
  guideStep: { 
    fontSize: 16, 
    color: '#666', 
    lineHeight: 24, 
    marginBottom: 12 
  },
  closeButton: { 
    backgroundColor: '#8B4513', 
    margin: 24, 
    marginTop: 16, 
    paddingVertical: 12, 
    borderRadius: 12, 
    alignItems: 'center' 
  },
  closeButtonText: { 
    color: '#FFFFFF', 
    fontSize: 16, 
    fontWeight: '600' 
  },
});

export default DashboardScreen;
