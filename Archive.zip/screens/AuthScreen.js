import React, { useState } from 'react';
import { Alert } from 'react-native';
import { supabase } from '../api/supabaseClient';

import LoginScreen from './LoginScreen';
import RegisterScreen from './RegisterScreen';

const AuthScreen = () => {
  const [isLoginView, setIsLoginView] = useState(true);
  const [loading, setLoading] = useState(false);

  // Enhanced login handler with better error handling
  const handleLogin = async (email, password) => {
    try {
      setLoading(true);      
      const loginPromise = supabase.auth.signInWithPassword({ email, password });
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Request timeout - please check your internet connection')), 15000)
      );
      
      const { data, error } = await Promise.race([loginPromise, timeoutPromise]);
      
      if (error) {
        console.error('Login error:', error);
        
        // More specific error messages
        if (error.message.includes('Network request failed') || error.message.includes('fetch')) {
          Alert.alert(
            "Koneksi Bermasalah", 
            "Tidak dapat terhubung ke server. Pastikan:\n• Internet aktif\n• Tidak ada firewall yang memblokir\n• Coba restart aplikasi"
          );
        } else {
          Alert.alert("Login Gagal", error.message);
        }
      } else {
        console.log('Login successful:', data);
      }
    } catch (error) {
      console.error('Unexpected error:', error);
      Alert.alert(
        "Error", 
        error.message || "Terjadi kesalahan yang tidak terduga"
      );
    } finally {
      setLoading(false);
    }
  };
 
  const handleRegister = async (email, password, username) => {
    try {
      setLoading(true);
      
      const registerPromise = supabase.auth.signUp({ 
        email, 
        password,
        options: {
          data: { 
            username: username 
          }
        }
      });
      
      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error('Request timeout - please check your internet connection')), 15000)
      );
      
      const { error } = await Promise.race([registerPromise, timeoutPromise]);

      if (error) {
        console.error('Register error:', error);
        
        if (error.message.includes('Network request failed') || error.message.includes('fetch')) {
          Alert.alert(
            "Koneksi Bermasalah", 
            "Tidak dapat terhubung ke server. Pastikan internet aktif dan coba lagi."
          );
        } else {
          Alert.alert("Registrasi Gagal", error.message);
        }
      } else {
        Alert.alert("Registrasi Berhasil", "Silakan periksa email Anda untuk verifikasi dan kemudian login.");
        setIsLoginView(true);
      }
    } catch (error) {
      console.error('Unexpected register error:', error);
      Alert.alert(
        "Error", 
        error.message || "Terjadi kesalahan yang tidak terduga"
      );
    } finally {
      setLoading(false);
    }
  };

  if (isLoginView) {
    return (
      <LoginScreen 
        onLogin={handleLogin} 
        onNavigateToRegister={() => setIsLoginView(false)}
        loading={loading}
      />
    );
  }
  return (
    <RegisterScreen 
      onRegister={handleRegister} 
      onNavigateToLogin={() => setIsLoginView(true)}
      loading={loading}
    />
  );
};

export default AuthScreen;