import React, { useState, useEffect } from 'react';  
import {  
  View,  
  Text,  
  StyleSheet,  
  ScrollView,  
  TouchableOpacity,  
  Image,  
  Alert,  
  Modal,  
  TextInput,  
} from 'react-native';  
import { supabase } from '../api/supabaseClient'; // Pastikan Anda mengimpor klien Supabase Anda  

const ProfileScreen = ({ user, onLogout }) => {  
  const [isEditing, setIsEditing] = useState(false);  
  const [profile, setProfile] = useState(null);  
  const [editedUsername, setEditedUsername] = useState('');  
  const [editedEmail, setEditedEmail] = useState('');  
  const [showLogoutModal, setShowLogoutModal] = useState(false);  

  // State untuk perubahan password  
  const [newPassword, setNewPassword] = useState('');  
  const [confirmPassword, setConfirmPassword] = useState('');  
  const [showPasswordModal, setShowPasswordModal] = useState(false);  

  // useEffect untuk mengambil data profil  
  useEffect(() => {  
    const fetchProfile = async () => {  
      if (user) {  
        const { data, error } = await supabase  
          .from('profiles')  
          .select('username, email')  
          .eq('id', user.id)  
          .single();  

        if (error) {  
          console.error('Error fetching profile:', error);  
          Alert.alert('Error', 'Could not fetch profile. Please check console for details.');  
          setProfile({ username: '', email: '' });  
        } else {  
          setProfile(data);  
          setEditedUsername(data.username); // Inisialisasi username untuk edit  
          setEditedEmail(data.email); // Inisialisasi email untuk edit  
        }  
      }  
    };  

    fetchProfile();  
  }, [user]);  

  const handleEditProfile = () => {  
    setIsEditing(true);  
  };  

  const handleSaveProfile = async () => {  
    console.log("Saving profile with:", { editedUsername, editedEmail });  
    if (editedUsername.trim() && editedEmail.trim()) {  
      // Update di tabel profiles  
      const { error: profileError } = await supabase  
        .from('profiles')  
        .update({ username: editedUsername, email: editedEmail })  
        .eq('id', user.id);  

      // Juga update email di tabel auth.users  
      const { error: userError } = await supabase  
        .auth.update({ email: editedEmail });  

      // Tangani error  
      if (profileError) {  
        Alert.alert('Error', 'Failed to update profile in profiles.');  
        console.error('Profile update error:', profileError);  
      }   
      if (userError) {  
        Alert.alert('Error', 'Failed to update email in auth.users.');  
        console.error('User email update error:', userError);  
      }  
      if (!profileError && !userError) {  
        // Update local state  
        setProfile({ username: editedUsername, email: editedEmail });  
        setIsEditing(false);  
        Alert.alert('Success', 'Profile updated successfully!');  
      }  
    } else {  
      Alert.alert('Error', 'Please fill in all fields');  
    }  
  };  

  // Function untuk Update Password  
  const handleChangePassword = async () => {  
    if (newPassword === confirmPassword) {  
      const { error } = await supabase.auth.update({ password: newPassword });  
      
      if (error) {  
        Alert.alert('Error', 'Failed to change password. Please try again.');  
        console.error('Password update error:', error);  
      } else {  
        Alert.alert('Success', 'Password updated successfully!');  
        setShowPasswordModal(false); // Tutup modal setelah berhasil  
        setNewPassword(''); // Reset dan kosongkan field password  
        setConfirmPassword(''); // Reset dan kosongkan field confirm password  
      }  
    } else {  
      Alert.alert('Error', 'Passwords do not match.');  
    }  
  };  

  const handleCancelEdit = () => {  
    // Reset ke data asli  
    setEditedUsername(profile?.username || '');  
    setEditedEmail(profile?.email || '');  
    setIsEditing(false);  
  };  

  const handleChangeProfilePhoto = () => {  
    Alert.alert('Change Profile Photo', 'This feature is coming soon!');  
  };  

  const handleDeleteAccount = () => {  
    Alert.alert(  
      'Delete Account',  
      'Are you sure you want to delete your account? This action cannot be undone.',  
      [  
        { text: 'Cancel', style: 'cancel' },  
        {  
          text: 'Delete',  
          style: 'destructive',  
          onPress: () => {  
            Alert.alert('Account Deleted', 'Your account has been deleted successfully.');  
            onLogout();  
          },  
        },  
      ]  
    );  
  };  

  const handleLogout = () => {  
    onLogout();  
    setShowLogoutModal(false);  
  };  

  const username = profile?.username || user?.email; // Menggunakan username dari profile  
  const profileImageUri = 'https://placehold.co/100x100/F5E6D3/8B4513?text=' + (username?.[0]?.toUpperCase() || 'U');  

  return (  
    <View style={styles.container}>  
      {/* Dark Brown Header */}  
      <View style={styles.header}>  
        <View style={styles.headerContent}>  
          <View style={styles.headerLeft}>  
            <Text style={styles.greeting}>Hi, {username}.</Text>  
          </View>  
          <TouchableOpacity  
            style={styles.profileButton}  
            onPress={() => setShowLogoutModal(true)}  
          >  
            <Image  
              source={{ uri: profileImageUri }}  
              style={styles.profileImage}  
            />  
          </TouchableOpacity>  
        </View>  
      </View>  

      {/* Main Content */}  
      <ScrollView style={styles.mainContent} showsVerticalScrollIndicator={false}>  
        <View style={styles.titleContainer}>  
          <Text style={styles.title}>Profile</Text>  
        </View>  

        {/* Profile Card */}  
        <View style={styles.profileCard}>  
          <View style={styles.avatarContainer}>  
            <Image  
              source={{ uri: profileImageUri }}  
              style={styles.avatar}  
            />  
            <TouchableOpacity  
              style={styles.cameraButton}  
              onPress={handleChangeProfilePhoto}  
            >  
              <Text style={styles.cameraIcon}>📷</Text>  
            </TouchableOpacity>  
          </View>  

          {isEditing ? (  
            <View style={styles.editForm}>  
              <View style={styles.inputContainer}>  
                <Text style={styles.label}>Username</Text>  
                <TextInput  
                  style={styles.input}  
                  value={editedUsername}  
                  onChangeText={setEditedUsername}  
                />  
              </View>  
              <View style={styles.inputContainer}>  
                <Text style={styles.label}>Email</Text>  
                <TextInput  
                  style={styles.input}  
                  value={editedEmail}  
                  onChangeText={setEditedEmail}  
                  keyboardType="email-address"  
                />  
              </View>  
              <View style={styles.editButtons}>  
                <TouchableOpacity  
                  style={[styles.editButton, styles.cancelEditButton]}  
                  onPress={handleCancelEdit}  
                >  
                  <Text style={styles.cancelEditButtonText}>Cancel</Text>  
                </TouchableOpacity>  
                <TouchableOpacity  
                  style={[styles.editButton, styles.saveButton]}  
                  onPress={handleSaveProfile}  
                >  
                  <Text style={styles.saveButtonText}>Save</Text>  
                </TouchableOpacity>  
              </View>  
            </View>  
          ) : (  
            <View style={styles.profileInfo}>  
              <Text style={styles.profileName}>{username}</Text>  
              <Text style={styles.profileEmail}>{profile?.email}</Text>  
              <TouchableOpacity  
                style={styles.editProfileButton}  
                onPress={handleEditProfile}  
              >  
                <Text style={styles.editIcon}>✏️</Text>  
                <Text style={styles.editProfileText}>Edit Profile</Text>  
              </TouchableOpacity>  
            </View>  
          )}  
        </View>  

        {/* Account Settings */}  
        <View style={styles.section}>  
          <Text style={styles.sectionTitle}>Account Settings</Text>  
          <TouchableOpacity style={styles.settingItem} onPress={() => setShowPasswordModal(true)}>  
            <View style={styles.settingIcon}><Text style={styles.settingIconText}>🔒</Text></View>  
            <View style={styles.settingContent}>  
              <Text style={styles.settingTitle}>Change Password</Text>  
              <Text style={styles.settingSubtitle}>Update your password</Text>  
            </View>  
            <Text style={styles.chevron}>›</Text>  
          </TouchableOpacity>  
        </View>  

        {/* Danger Zone */}  
        <View style={styles.section}>  
          <Text style={styles.dangerTitle}>Danger Zone</Text>  
          <TouchableOpacity style={styles.dangerItem} onPress={handleDeleteAccount}>  
            <View style={styles.dangerIcon}><Text style={styles.dangerIconText}>🗑️</Text></View>  
            <View style={styles.settingContent}>  
              <Text style={styles.dangerText}>Delete Account</Text>  
              <Text style={styles.dangerSubtext}>Permanently delete your account and data</Text>  
            </View>  
            <Text style={styles.dangerChevron}>›</Text>  
          </TouchableOpacity>  
        </View>  
      </ScrollView>  

      {/* Modal untuk Mengubah Password */}  
      <Modal  
        visible={showPasswordModal}  
        transparent  
        animationType="slide"  
        onRequestClose={() => setShowPasswordModal(false)}  
      >  
        <View style={styles.modalOverlay}>  
          <View style={styles.modalContent}>  
            <Text style={styles.modalTitle}>Change Password</Text>  
            <TextInput  
              placeholder="New Password"  
              style={styles.input}  
              onChangeText={setNewPassword}  
              secureTextEntry  
              value={newPassword}  
            />  
            <TextInput  
              placeholder="Confirm Password"  
              style={styles.input}  
              onChangeText={setConfirmPassword}  
              secureTextEntry  
              value={confirmPassword}  
            />  
            <View style={styles.modalButtons}>  
              <TouchableOpacity   
                style={[styles.modalButton, styles.cancelButton]}  
                onPress={() => setShowPasswordModal(false)}  
              >  
                <Text style={styles.cancelButtonText}>Cancel</Text>  
              </TouchableOpacity>  
              <TouchableOpacity   
                style={[styles.modalButton, styles.confirmButton]}  
                onPress={handleChangePassword}  
              >  
                <Text style={styles.confirmButtonText}>Change</Text>  
              </TouchableOpacity>  
            </View>  
          </View>  
        </View>  
      </Modal>  

      {/* Logout Modal */}  
      <Modal visible={showLogoutModal} transparent animationType="fade" onRequestClose={() => setShowLogoutModal(false)}>  
        <View style={styles.modalOverlay}>  
          <View style={styles.modalContent}>  
            <Text style={styles.logoutIcon}>🚪</Text>  
            <Text style={styles.modalTitle}>Logout</Text>  
            <Text style={styles.modalText}>Are you sure you want to logout?</Text>  
            <View style={styles.modalButtons}>  
              <TouchableOpacity style={[styles.modalButton, styles.cancelButton]} onPress={() => setShowLogoutModal(false)}>  
                <Text style={styles.cancelButtonText}>Cancel</Text>  
              </TouchableOpacity>  
              <TouchableOpacity style={[styles.modalButton, styles.confirmButton]} onPress={handleLogout}>  
                <Text style={styles.confirmButtonText}>Logout</Text>  
              </TouchableOpacity>  
            </View>  
          </View>  
        </View>  
      </Modal>  
    </View>  
  );  
};  

const styles = StyleSheet.create({  
  container: {  
    flex: 1,  
    backgroundColor: '#F5E6D3',  
  },  
  header: {  
    backgroundColor: '#5D2E0A',  
    paddingBottom: 16,  
    paddingTop: 40,  
  },  
  headerContent: {  
    flexDirection: 'row',  
    justifyContent: 'space-between',  
    alignItems: 'center',  
    paddingHorizontal: 20,  
    paddingTop: 10,  
  },  
  headerLeft: {  
    flex: 1,  
  },  
  greeting: {  
    fontSize: 24,  
    fontWeight: 'bold',  
    color: '#FFFFFF',  
  },  
  profileButton: {  
    borderRadius: 25,  
    overflow: 'hidden',  
    borderWidth: 3,  
    borderColor: '#FFFFFF',  
  },  
  profileImage: {  
    width: 50,  
    height: 50,  
    borderRadius: 25,  
  },  
  mainContent: {  
    flex: 1,  
  },  
  titleContainer: {  
    padding: 20,  
    paddingTop: 10,  
  },  
  title: {  
    fontSize: 28,  
    fontWeight: 'bold',  
    color: '#8B4513',  
  },  
  profileCard: {  
    backgroundColor: '#FFFFFF',  
    marginHorizontal: 20,  
    marginBottom: 24,  
    borderRadius: 20,  
    padding: 24,  
    alignItems: 'center',  
    shadowColor: '#000',  
    shadowOffset: { width: 0, height: 4 },  
    shadowOpacity: 0.15,  
    shadowRadius: 8,  
    elevation: 8,  
  },  
  avatarContainer: {  
    position: 'relative',  
    marginBottom: 16,  
  },  
  avatar: {  
    width: 100,  
    height: 100,  
    borderRadius: 50,  
    borderWidth: 4,  
    borderColor: '#F5E6D3',  
  },  
  cameraButton: {  
    position: 'absolute',  
    bottom: 0,  
    right: 0,  
    backgroundColor: '#8B4513',  
    borderRadius: 16,  
    width: 32,  
    height: 32,  
    justifyContent: 'center',  
    alignItems: 'center',  
    borderWidth: 3,  
    borderColor: '#FFFFFF',  
  },  
  cameraIcon: {  
    fontSize: 16,  
  },  
  profileInfo: {  
    alignItems: 'center',  
  },  
  profileName: {  
    fontSize: 24,  
    fontWeight: 'bold',  
    color: '#333',  
    marginBottom: 4,  
  },  
  profileEmail: {  
    fontSize: 16,  
    color: '#666',  
    marginBottom: 16,  
  },  
  editProfileButton: {  
    flexDirection: 'row',  
    alignItems: 'center',  
    backgroundColor: '#F5E6D3',  
    paddingHorizontal: 16,  
    paddingVertical: 8,  
    borderRadius: 20,  
    gap: 8,  
  },  
  changePasswordButton: {  
    backgroundColor: '#5D2E0A',  
    padding: 12,  
    borderRadius: 8,  
    margin: 20,  
    alignItems: 'center',  
  },  
  changePasswordText: {  
    color: '#FFFFFF',  
    fontSize: 16,  
    fontWeight: '600',  
  },  
  editForm: {  
    width: '100%',  
  },  
  inputContainer: {  
    marginBottom: 16,  
  },  
  label: {  
    fontSize: 14,  
    fontWeight: '600',  
    color: '#333',  
    marginBottom: 8,  
  },  
  input: {  
    borderWidth: 1,  
    borderColor: '#E0E0E0',  
    borderRadius: 12,  
    paddingHorizontal: 16,  
    paddingVertical: 12,  
    fontSize: 16,  
    backgroundColor: '#FFFFFF',  
  },  
  editButtons: {  
    flexDirection: 'row',  
    gap: 12,  
    marginTop: 16,  
  },  
  editButton: {  
    flex: 1,  
    paddingVertical: 12,  
    borderRadius: 12,  
    alignItems: 'center',  
  },  
  cancelEditButton: {  
    backgroundColor: '#F0F0F0',  
  },  
  saveButton: {  
    backgroundColor: '#8B4513',  
  },  
  cancelEditButtonText: {  
    color: '#666',  
    fontWeight: '600',  
  },  
  saveButtonText: {  
    color: '#FFFFFF',  
    fontWeight: '600',  
  },  
  section: {  
    marginBottom: 24,  
  },  
  sectionTitle: {  
    fontSize: 18,  
    fontWeight: 'bold',  
    color: '#8B4513',  
    marginBottom: 12,  
    paddingHorizontal: 20,  
  },  
  dangerTitle: {  
    fontSize: 18,  
    fontWeight: 'bold',  
    color: '#F44336',  
    marginBottom: 12,  
    paddingHorizontal: 20,  
  },  
  settingItem: {  
    flexDirection: 'row',  
    alignItems: 'center',  
    backgroundColor: '#FFFFFF',  
    marginHorizontal: 20,  
    marginBottom: 2,  
    padding: 16,  
    borderRadius: 12,  
    shadowColor: '#000',  
    shadowOffset: { width: 0, height: 1 },  
    shadowOpacity: 0.05,  
    shadowRadius: 2,  
    elevation: 1,  
  },  
  dangerItem: {  
    flexDirection: 'row',  
    alignItems: 'center',  
    backgroundColor: '#F44336',  
    marginHorizontal: 20,  
    marginBottom: 2,  
    padding: 16,  
    borderRadius: 12,  
    shadowColor: '#000',  
    shadowOffset: { width: 0, height: 2 },  
    shadowOpacity: 0.15,  
    shadowRadius: 4,  
    elevation: 3,  
  },  
  settingIcon: {  
    width: 40,  
    height: 40,  
    borderRadius: 20,  
    backgroundColor: '#F5E6D3',  
    justifyContent: 'center',  
    alignItems: 'center',  
    marginRight: 16,  
  },  
  dangerIcon: {  
    width: 40,  
    height: 40,  
    borderRadius: 20,  
    backgroundColor: 'rgba(255,255,255,0.2)',  
    justifyContent: 'center',  
    alignItems: 'center',  
    marginRight: 16,  
  },  
  settingIconText: {  
    fontSize: 20,  
  },  
  dangerIconText: {  
    fontSize: 20,  
  },  
  settingContent: {  
    flex: 1,  
  },  
  settingTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#333',
    marginBottom: 2,
  },
  settingSubtitle: {
    fontSize: 14,
    color: '#666',
  },
  dangerText: {
    fontSize: 16,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  dangerSubtext: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.8)',
  },
  chevron: {
    fontSize: 20,
    color: '#A0A0A0',
  },
  dangerChevron: {
    fontSize: 20,
    color: '#FFFFFF',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 24,
    alignItems: 'center',
    marginHorizontal: 40,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
    elevation: 8,
  },
  logoutIcon: {
    fontSize: 48,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#333',
    marginTop: 16,
    marginBottom: 8,
  },
  modalText: {
    fontSize: 16,
    color: '#666',
    textAlign: 'center',
    marginBottom: 24,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: 12,
  },
  modalButton: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    borderRadius: 12,
    minWidth: 80,
    alignItems: 'center',
  },
  cancelButton: {
    backgroundColor: '#F0F0F0',
  },
  confirmButton: {
    backgroundColor: '#8B4513',
  },
  cancelButtonText: {
    color: '#666',
    fontWeight: '600',
  },
  confirmButtonText: {
    color: '#FFFFFF',
    fontWeight: '600',
  },
});

export default ProfileScreen;