import React, { useState, useRef, useEffect, useContext } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  PanResponder, 
  Animated,
  ActivityIndicator,
  Button
} from 'react-native';
import { WebView } from 'react-native-webview';

import { useSettings } from '../context/SettingsContext';
import { ThemeContext } from '../context/ThemeContext';
import { dummyData } from '../api/dummyData';

const MonitoringScreen = ({ onTabPress }) => {
  const { streamUrl, isLoading } = useSettings();
  const { isDarkMode } = useContext(ThemeContext);

  const [liveStats, setLiveStats] = useState(null);
  const [livePower, setLivePower] = useState(null);
  const [connectionError, setConnectionError] = useState(null);
  const [cameraHeight, setCameraHeight] = useState(220);
  const [isRecording, setIsRecording] = useState(false);
  
  // State untuk mengontrol visibilitas loading overlay kustom untuk WebView
  const [isWebViewLoading, setIsWebViewLoading] = useState(true);

  const panResponder = useRef(
    PanResponder.create({
      onMoveShouldSetPanResponder: () => true,
      onPanResponderMove: (event, gestureState) => {
        setCameraHeight(prevHeight => Math.max(150, prevHeight + gestureState.dy));
      },
    })
  ).current;

  // useEffect untuk mengambil data API (deteksi & sensor)
  useEffect(() => {
    if (!streamUrl) return;

    const fetchData = async () => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 4000); // Timeout 4 detik

        const [detectionResponse, sensorResponse] = await Promise.all([
          fetch(`http://${streamUrl}:8000/detection`, { signal: controller.signal }),
          fetch(`http://${streamUrl}:8000/sensor`, { signal: controller.signal })
        ]);
        
        clearTimeout(timeoutId);

        if (!detectionResponse.ok || !sensorResponse.ok) {
          throw new Error("Gagal mengambil data dari server Pi.");
        }

        const detectionJson = await detectionResponse.json();
        const sensorJson = await sensorResponse.json();
        
        setLiveStats(detectionJson.detection);
        setLivePower(sensorJson.sensor);
        if (connectionError) setConnectionError(null);

      } catch (error) {
        console.error("Gagal mengambil data live dari Pi:", error);
        setConnectionError("Koneksi ke Raspberry Pi Gagal. Periksa jaringan & alamat.");
      }
    };

    fetchData();
    const intervalId = setInterval(fetchData, 5000);
    return () => clearInterval(intervalId);
  }, [streamUrl]);

  // useEffect untuk menyembunyikan loading WebView setelah beberapa saat
  useEffect(() => {
    setIsWebViewLoading(true); 
    const timer = setTimeout(() => {
      setIsWebViewLoading(false); // Sembunyikan loading setelah 4 detik
    }, 4000);
    
    return () => clearTimeout(timer);
  }, [streamUrl]);

  const handleWebViewError = (syntheticEvent) => {
    const { nativeEvent } = syntheticEvent;
    if (!connectionError) {
        setConnectionError(`Gagal memuat video stream (${nativeEvent.description}).`);
    }
  };

  // Kumpulan Gaya Dinamis
  const mainContainerStyle = [styles.mainContainer, isDarkMode && styles.mainContainerDark];
  const headerStyle = [styles.header, isDarkMode && styles.headerDark];
  const headerTextStyle = [styles.headerText, isDarkMode && styles.textDark];
  const sectionTitleStyle = [styles.sectionTitle, isDarkMode && styles.sectionTitleDark];
  const statsContainerStyle = [styles.statsContainer, isDarkMode && styles.statsContainerDark];
  const statValueStyle = [styles.statValue, isDarkMode && styles.statValueDark];
  const statLabelStyle = [styles.statLabel, isDarkMode && styles.statLabelDark];
  const qualityTitleStyle = [styles.qualityTitle, isDarkMode && styles.qualityTitleDark];
  const qualityTextStyle = [styles.qualityText, isDarkMode && styles.qualityTextDark];
  const detailTextStyle = [styles.detailText, isDarkMode && styles.detailTextDark];
  const powerCircleStyle = [styles.powerCircle, isDarkMode && styles.powerCircleDark];
  const powerValueStyle = [styles.powerValue, isDarkMode && styles.textDark];
  const powerLabelStyle = [styles.powerLabel, isDarkMode && styles.qualityTitleDark];
  const historyItemStyle = [styles.historyItem, isDarkMode && styles.historyItemDark];
  const historyDateStyle = [styles.historyDate, isDarkMode && styles.subtextDark];
  const historyDetailStyle = [styles.historyDetail, isDarkMode && styles.subtextDark];
  const centeredMessageStyle = [styles.centeredMessage, isDarkMode && styles.mainContainerDark];
  const messageTextStyle = [styles.messageText, isDarkMode && styles.textDark];
  
  if (isLoading) {
    return (
        <View style={centeredMessageStyle}>
            <ActivityIndicator size="large" color={isDarkMode ? "#D4A57F" : "#92400E"}/>
            <Text style={messageTextStyle}>Memuat Konfigurasi...</Text>
        </View>
    );
  }

  if (!streamUrl) {
    return (
      <View style={centeredMessageStyle}>
        <Text style={messageTextStyle}>Alamat stream kamera belum diatur.</Text>
        <Button title="Buka Pengaturan" onPress={() => onTabPress('settings')} color="#92400E"/>
      </View>
    );
  }

  const videoFeedUrl = `http://${streamUrl}:8000/video_feed`;

  return (
    <SafeAreaView style={mainContainerStyle}>
      <View style={headerStyle}>
        <Text style={headerTextStyle}>Monitoring</Text>
        <Text style={styles.headerIcon}>👥</Text>
      </View>

      {connectionError && (
        <View style={styles.errorContainer}>
          <Text style={styles.errorIcon}>⚠️</Text>
          <Text style={styles.errorText}>{connectionError}</Text>
          <TouchableOpacity onPress={() => onTabPress('settings')} style={styles.errorButton}>
             <Text style={styles.errorButtonText}>Pengaturan</Text>
          </TouchableOpacity>
        </View>
      )}

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <Animated.View style={styles.cameraSectionContainer}>
          <View style={[styles.cameraView, isDarkMode && styles.cameraViewDark, { height: cameraHeight }]}>
            <WebView
              source={{ uri: videoFeedUrl }}
              style={styles.cameraImage}
              onError={handleWebViewError}
              containerStyle={{backgroundColor: isDarkMode ? '#1E1E1E' : '#FFF'}}
              originWhitelist={['*']}
            />
            {isWebViewLoading && (
              <View style={styles.webviewLoading}>
                <ActivityIndicator size="large" color={isDarkMode ? "#D4A57F" : "#92400E"} />
                <Text style={[styles.loadingText, isDarkMode && styles.textDark]}>Memulai stream...</Text>
              </View>
            )}
            <TouchableOpacity style={styles.cameraSettingsButton} onPress={() => onTabPress('settings')}>
              <Text style={styles.cameraSettingsIcon}>⚙️</Text>
            </TouchableOpacity>
          </View>
          <View style={styles.resizeHandleWrapper} {...panResponder.panHandlers}>
            <View style={[styles.resizeHandle, isDarkMode && styles.resizeHandleDark]} />
          </View>
          <View style={styles.controlsContainer}>
            <TouchableOpacity style={[styles.controlButton, isDarkMode && styles.controlButtonDark]} onPress={() => setIsRecording(!isRecording)}>
              <Text style={styles.controlButtonText}>{isRecording ? '⏸️' : '▶️'}</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.controlButton, isDarkMode && styles.controlButtonDark]}>
              <Text style={styles.controlButtonText}>⏹️</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.controlButton, isDarkMode && styles.controlButtonDark]}>
              <Text style={styles.controlButtonText}>⏺️</Text>
            </TouchableOpacity>
          </View>
        </Animated.View>

        <View style={statsContainerStyle}>
          <View style={styles.statsRow}>
            <View style={styles.statItem}>
              <Text style={statValueStyle}>{liveStats ? liveStats.total.toLocaleString() : '...'}</Text>
              <Text style={statLabelStyle}>Processed</Text>
            </View>
            <View style={styles.statItem}>
              <Text style={statValueStyle}>{liveStats ? `${liveStats.good_percentage.toFixed(1)}%` : '...'}</Text>
              <Text style={statLabelStyle}>Efficiency</Text>
            </View>
          </View>
          <Text style={qualityTitleStyle}>Quality Distribution</Text>
          <View style={styles.progressBarContainer}>
            <View style={[styles.progressBarBackground, isDarkMode && styles.progressBarBackgroundDark]}>
              <View style={[styles.progressBarFill, { width: liveStats ? `${liveStats.good_percentage}%` : '0%' }]}/>
            </View>
          </View>
          <Text style={qualityTextStyle}>
            {liveStats ? `${liveStats.good_percentage.toFixed(1)}% (${liveStats.good} out of ${liveStats.total} good)`: 'Menunggu data...'}
          </Text>
          <View style={styles.qualityDetails}>
            <Text style={detailTextStyle}>Good: {liveStats ? liveStats.good_percentage.toFixed(1) : '0.0'}%</Text>
            <Text style={detailTextStyle}>Bad: {liveStats ? liveStats.bad_percentage.toFixed(1) : '0.0'}%</Text>
          </View>
        </View>

        <Text style={sectionTitleStyle}>Power Monitoring</Text>
        <View style={styles.powerMonitoringContainer}>
          <View style={styles.powerItem}>
            <View style={powerCircleStyle}>
              <Text style={powerValueStyle}>{livePower ? livePower.voltage.toFixed(1) : '...'}</Text>
              <Text style={styles.powerStatus}>Normal</Text>
            </View>
            <Text style={powerLabelStyle}>Voltage</Text>
          </View>
          <View style={styles.powerItem}>
            <View style={powerCircleStyle}>
              <Text style={powerValueStyle}>{livePower ? livePower.current.toFixed(2) : '...'}</Text>
              <Text style={styles.powerStatus}>Normal</Text>
            </View>
            <Text style={powerLabelStyle}>Current</Text>
          </View>
          <View style={styles.powerItem}>
            <View style={powerCircleStyle}>
              <Text style={powerValueStyle}>{livePower ? livePower.power.toFixed(1) : '...'}</Text>
              <Text style={styles.powerStatus}>Normal</Text>
            </View>
            <Text style={powerLabelStyle}>Power</Text>
          </View>
        </View>

        <Text style={sectionTitleStyle}>Selection History</Text>
        <View style={styles.historyContainer}>
          {dummyData.selectionHistory.map((item) => (
            <View key={item.id} style={historyItemStyle}>
              <View style={styles.historyHeader}>
                <Text style={historyDateStyle}>{item.date}</Text>
                <Text style={[styles.historyStatus, { color: item.status === 'Completed' ? '#10B981' : '#EF4444' }]}>
                  {item.status}
                </Text>
              </View>
              <Text style={historyDetailStyle}>Processed: {item.processed} beans</Text>
              <Text style={historyDetailStyle}>{item.good}% Good | {item.rejected}% Reject</Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  mainContainer: { flex: 1, backgroundColor: '#F3F4F6' },
  header: { backgroundColor: '#92400E', flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 20, paddingVertical: 16 },
  headerText: { color: 'white', fontSize: 18, fontWeight: 'bold' },
  headerIcon: { color: 'white', fontSize: 20 },
  content: { flex: 1, padding: 20 },
  cameraSectionContainer: { marginBottom: 32 },
  cameraView: { backgroundColor: 'white', borderRadius: 24, overflow: 'hidden', borderWidth: 2, borderColor: '#E5E7EB', position: 'relative' },
  cameraImage: { width: '100%', height: '100%' },
  cameraSettingsButton: { position: 'absolute', top: 8, right: 8, padding: 4, zIndex: 10 },
  cameraSettingsIcon: { fontSize: 20, color: '#FFFFFF', textShadowColor: 'rgba(0, 0, 0, 0.75)', textShadowOffset: {width: -1, height: 1}, textShadowRadius: 5 },
  resizeHandleWrapper: { width: '100%', paddingVertical: 10, alignItems: 'center', justifyContent: 'center' },
  resizeHandle: { width: 60, height: 6, backgroundColor: '#D1D5DB', borderRadius: 3 },
  controlsContainer: { flexDirection: 'row', justifyContent: 'center', marginTop: 8 },
  controlButton: { width: 48, height: 48, borderRadius: 24, backgroundColor: 'white', justifyContent: 'center', alignItems: 'center', marginHorizontal: 8, elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2 },
  controlButtonText: { fontSize: 16 },
  statsContainer: { backgroundColor: '#FEF3C7', padding: 20, borderRadius: 24, marginBottom: 32 },
  statsRow: { flexDirection: 'row', justifyContent: 'space-around', marginBottom: 20 },
  statItem: { alignItems: 'center' },
  statValue: { fontSize: 32, fontWeight: 'bold', color: '#78350F' },
  statLabel: { fontSize: 14, color: '#A16207', marginTop: 4 },
  qualityTitle: { fontSize: 16, fontWeight: 'bold', color: '#78350F', marginBottom: 12 },
  progressBarContainer: { marginBottom: 8 },
  progressBarBackground: { height: 8, backgroundColor: '#E5E7EB', borderRadius: 4 },
  progressBarFill: { height: '100%', backgroundColor: '#92400E', borderRadius: 4 },
  qualityText: { fontSize: 14, color: '#A16207', marginBottom: 10 },
  qualityDetails: { marginTop: 5, paddingTop: 10, borderTopWidth: 1, borderTopColor: '#E5E7EB' },
  detailText: { fontSize: 13, color: '#6B7280', marginBottom: 4 },
  sectionTitle: { fontSize: 20, fontWeight: 'bold', color: '#78350F', marginBottom: 16 },
  powerMonitoringContainer: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 32 },
  powerItem: { alignItems: 'center', flex: 1 },
  powerCircle: { width: 90, height: 90, backgroundColor: 'white', borderRadius: 45, justifyContent: 'center', alignItems: 'center', borderWidth: 4, borderColor: '#92400E', marginBottom: 12, elevation: 2, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.1, shadowRadius: 2 },
  powerValue: { fontSize: 16, fontWeight: 'bold', color: '#78350F' },
  powerStatus: { fontSize: 12, color: '#16A34A' },
  powerLabel: { fontSize: 14, color: '#78350F', fontWeight: '500', textAlign: 'center' },
  historyContainer: { marginBottom: 20 },
  historyItem: { backgroundColor: 'white', padding: 16, borderRadius: 16, marginBottom: 12, elevation: 1, shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 2 },
  historyHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  historyDate: { fontSize: 14, color: '#6B7280' },
  historyStatus: { fontSize: 14, fontWeight: 'bold' },
  historyDetail: { fontSize: 12, color: '#9CA3AF', marginBottom: 4 },
  centeredMessage: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 20, backgroundColor: '#F3F4F6' },
  messageText: { fontSize: 18, textAlign: 'center', marginBottom: 20, color: '#374151' },
  errorContainer: { backgroundColor: '#EF4444', paddingVertical: 10, paddingHorizontal: 15, marginHorizontal: 20, marginTop: 10, borderRadius: 12, flexDirection: 'row', alignItems: 'center', elevation: 4, shadowColor: '#000', shadowOffset: { width: 0, height: 2}, shadowOpacity: 0.2, shadowRadius: 4 },
  errorIcon: { fontSize: 20, marginRight: 12 },
  errorText: { flex: 1, color: 'white', fontWeight: '600', fontSize: 14 },
  errorButton: { marginLeft: 10, paddingHorizontal: 12, paddingVertical: 6, backgroundColor: 'rgba(255,255,255,0.2)', borderRadius: 8 },
  errorButtonText: { color: 'white', fontWeight: 'bold', fontSize: 12 },
  webviewLoading: { position: 'absolute', top: 0, left: 0, right: 0, bottom: 0, justifyContent: 'center', alignItems: 'center', backgroundColor: 'rgba(0, 0, 0, 0.3)', borderRadius: 22 },
  loadingText: { marginTop: 10, color: '#FFF', fontWeight: '600', textShadowColor: 'rgba(0, 0, 0, 0.75)', textShadowOffset: {width: 0, height: 1}, textShadowRadius: 2 },
  
  // --- Dark Mode Styles ---
  mainContainerDark: { backgroundColor: '#121212' },
  headerDark: { backgroundColor: '#1E1E1E', borderBottomWidth: 1, borderBottomColor: '#2C2C2C' },
  textDark: { color: '#E0E0E0' },
  subtextDark: { color: '#A0A0A0' },
  cameraViewDark: { backgroundColor: '#1E1E1E', borderColor: '#2C2C2C' },
  resizeHandleDark: { backgroundColor: '#4A4A4A' },
  controlButtonDark: { backgroundColor: '#2C2C2C' },
  sectionTitleDark: { color: '#D4A57F' },
  statsContainerDark: { backgroundColor: '#1E1E1E' },
  statValueDark: { color: '#D4A57F' },
  statLabelDark: { color: '#A0A0A0' },
  qualityTitleDark: { color: '#D4A57F' },
  qualityTextDark: { color: '#A0A0A0' },
  detailTextDark: { color: '#A0A0A0' },
  powerCircleDark: { backgroundColor: '#2C2C2C', borderColor: '#D4A57F' },
  powerLabelDark: { color: '#D4A57F' },
  historyItemDark: { backgroundColor: '#1E1E1E' },
  historyDateDark: { color: '#A0A0A0' },
  historyDetailDark: { color: '#888888' },
  progressBarBackgroundDark: {backgroundColor: '#4A4A4A'},
});

export default MonitoringScreen;