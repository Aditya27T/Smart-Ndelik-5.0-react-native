import React from 'react';
import { 
  View, 
  Text, 
  StyleSheet, 
  ScrollView, 
  Image, 
  TouchableOpacity,
  SafeAreaView
} from 'react-native';

// Komponen ini menerima 2 props:
// 1. coffee: Objek yang berisi semua data kopi yang dipilih (nama, gambar, artikel)
// 2. onClose: Fungsi untuk kembali ke halaman Dashboard
const ArticleScreen = ({ coffee, onClose }) => {
  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header dengan tombol kembali dan judul */}
        <View style={styles.header}>
          <TouchableOpacity onPress={onClose} style={styles.backButton}>
            <Text style={styles.backButtonText}>‹</Text>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>{coffee.name}</Text>
        </View>

        {/* Konten artikel yang bisa di-scroll */}
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <Image source={{ uri: coffee.articleImage }} style={styles.articleImage} />
          <Text style={styles.articleText}>{coffee.article}</Text>
        </ScrollView>
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#5D2E0A', // Warna gelap untuk area atas (notch)
  },
  container: {
    flex: 1,
    backgroundColor: '#F5E6D3', // Warna background konten
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#5D2E0A', // Warna header cokelat tua
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  backButton: {
    paddingRight: 16,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 30,
    fontWeight: 'bold',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  scrollContent: {
    padding: 20,
  },
  articleImage: {
    width: '100%',
    height: 200,
    borderRadius: 16,
    marginBottom: 20,
  },
  articleText: {
    fontSize: 16,
    color: '#333333',
    lineHeight: 24, // Jarak antar baris agar mudah dibaca
    textAlign: 'justify',
  },
});

export default ArticleScreen;
