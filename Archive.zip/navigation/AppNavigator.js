import React, { useState, useEffect, createContext, useCallback, useMemo } from 'react';
import { View, StyleSheet, Alert, StatusBar } from 'react-native';

import { supabase } from '../api/supabaseClient';

import { ThemeContext } from '../context/ThemeContext';

import SplashScreen from '../screens/SplashScreen';
import AuthScreen from '../screens/AuthScreen';
import DashboardScreen from '../screens/DashboardScreen';
import MonitoringScreen from '../screens/MonitoringScreen';
import SettingsScreen from '../screens/SettingsScreen';
import ProfileScreen from '../screens/ProfileScreen';
import BottomNavigation from '../components/BottomNavigation';

const AppNavigator = () => {
  const [initializing, setInitializing] = useState(true);
  const [session, setSession] = useState(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isDarkMode, setIsDarkMode] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setInitializing(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });
    
    return () => subscription.unsubscribe();
  }, []);

  // ==========================================================
  // --- HANDLERS & LOGIC (BAGIAN INI SEKARANG DILENGKAPI) ---
  // ==========================================================

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      Alert.alert("Logout Gagal", error.message);
      console.error("Logout error:", error);
    }
    setActiveTab('dashboard');
  };

  const handleUpdateUser = async (updatedData) => {
    if (!session?.user) return;
    const { data, error } = await supabase.auth.updateUser({ 
        email: updatedData.email,
        data: { username: updatedData.username } 
    });
    
    if (error) {
      Alert.alert('Update Gagal', error.message);
    } else {
      Alert.alert('Sukses', 'Profil berhasil diperbarui!');
    }
  };

  const handleChangePassword = async (newPassword) => {
    const { error } = await supabase.auth.updateUser({ password: newPassword });
    if (error) {
      Alert.alert('Gagal Mengubah Password', error.message);
    } else {
      Alert.alert('Sukses', 'Password Anda telah berhasil diubah.');
    }
  };

  const handleDeleteAccount = () => {
    Alert.alert(
      'Hapus Akun',
      'Apakah Anda yakin ingin menghapus akun Anda? Tindakan ini tidak dapat dibatalkan.',
      [
        { text: 'Batal', style: 'cancel' },
        {
          text: 'Hapus',
          style: 'destructive',
          onPress: async () => {
            console.log("Simulasi penghapusan akun. Pengguna akan di-logout.");
            await handleLogout();
          },
        },
      ]
    );
  };

  const handleTabPress = (tabId) => {
    setActiveTab(tabId);
  };

  const toggleTheme = useCallback(() => {
    setIsDarkMode(previousState => !previousState);
  }, []);

  const themeValue = useMemo(
    () => ({ isDarkMode, toggleTheme }),
    [isDarkMode, toggleTheme]
  );
  
  const renderMainScreen = () => {
    if (!session || !session.user) return null;
    const screenProps = {
      user: session.user,
      onLogout: handleLogout,
      onUpdateUser: handleUpdateUser,
      onDeleteAccount: handleDeleteAccount,
      onChangePassword: handleChangePassword, 
      onTabPress: handleTabPress,
    };

    let ScreenComponent;
    switch (activeTab) {
      case 'dashboard': ScreenComponent = DashboardScreen; break;
      case 'monitoring': ScreenComponent = MonitoringScreen; break;
      case 'settings': ScreenComponent = SettingsScreen; break;
      case 'profile': ScreenComponent = ProfileScreen; break;
      default: ScreenComponent = DashboardScreen;
    }
    return <ScreenComponent {...screenProps} />;
  };
  
  const renderContent = () => {
      if (initializing) {
          return <SplashScreen />;
      }
      if (!session) {
          return <AuthScreen />;
      }
      return (
          <View style={styles.appContainer}>
              <View style={{flex: 1}}>
                {renderMainScreen()}
              </View>
              <BottomNavigation 
                activeTab={activeTab} 
                onTabPress={handleTabPress} 
                isDarkMode={isDarkMode}
              />
          </View>
      );
  };

  return (
    <ThemeContext.Provider value={themeValue}>
      <StatusBar barStyle={isDarkMode ? 'light-content' : 'dark-content'} />
      {renderContent()}
    </ThemeContext.Provider>
  );
};

const styles = StyleSheet.create({
  appContainer: {
    flex: 1,
  },
});

export default AppNavigator;