import React, { createContext, useState, useEffect, useContext } from 'react';
import { Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const SettingsContext = createContext();

export const SettingsProvider = ({ children }) => {
  const [streamUrl, setStreamUrl] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const [isYoloEnabled, setIsYoloEnabled] = useState(true);

  useEffect(() => {
    const loadSettingsFromStorage = async () => {
      try {
        const savedUrl = await AsyncStorage.getItem('stream_url');
        if (savedUrl !== null) {
          setStreamUrl(savedUrl);
        }
      } catch (e) {
        console.error('Gagal memuat pengaturan.', e);
      } finally {
        setIsLoading(false);
      }
    };
    loadSettingsFromStorage();
  }, []);

  const saveStreamUrl = async (url) => {
    try {
      await AsyncStorage.setItem('stream_url', url);
      setStreamUrl(url);
    } catch (e) {
      console.error('Gagal menyimpan URL stream.', e);
    }
  };

  const toggleYolo = async (newValue) => {
    if (!streamUrl) {
      Alert.alert("Gagal", "Alamat stream belum diatur. Silakan atur terlebih dahulu.");
      return;
    }
    
    const state = newValue ? 'on' : 'off';
    const endpoint = `http://${streamUrl}:8000/toggle_yolo/${state}`;

    try {
      const response = await fetch(endpoint);
      const data = await response.json();

      if (response.ok && data.status === 'success') {
        setIsYoloEnabled(newValue); 
        Alert.alert("Sukses", data.message);
      } else {
        Alert.alert("Error", data.error || "Gagal mengubah status deteksi.");
      }
    } catch (error) {
      console.error("Error toggling YOLO:", error);
      Alert.alert("Koneksi Gagal", "Tidak dapat terhubung ke server Raspberry Pi.");
    }
  };

  const value = {
    streamUrl,
    saveStreamUrl,
    isLoading,
    isYoloEnabled, 
    toggleYolo,    
  };

  return (
    <SettingsContext.Provider value={value}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  return useContext(SettingsContext);
};